﻿#pragma once
#include <unordered_map>
#include <string>
#include <fstream>
#include <sstream>

struct AttackParam
{
	float hitStartFrame = 10.0f;
	float hitEndFrame = 25.0f;
	float cancelFrame = 30.0f;
};

class PlayerParamManager
{
public:
	static PlayerParamManager& Instance()
	{
		static PlayerParamManager instance;
		return instance;
	}

	void Load(const std::string& filepath);
	void Save(const std::string& filepath);

	void LoadWeaponParams(const std::string& filepath);
	void SaveWeaponParams(const std::string& filepath);

	// 攻撃パラメータの取得
	// （未登録の場合はデフォルト値で登録してから返す）
	AttackParam GetAttackParam(const std::string& animName)
	{
		return m_attackParams[animName];
	}

	// GUI調整用にMapを渡す
	std::unordered_map<std::string, AttackParam>& GetAttackMap() { return m_attackParams; }

	float m_evadeSpeed = 0.4f;
	float m_dashSpeed = 0.5f;		// ※ダッシュは削除したので使っていない（PlayerParams.txt の形式を変えないために残している）
	float m_attackRootScale = 1.0f;

private:
	PlayerParamManager() {}
	~PlayerParamManager() {}

	// 武器パラメータ（JSONのキー名と、対応するPlayerの静的変数）
	struct WeaponParamEntry
	{
		const char*		key;
		Math::Vector3*	pos;
		Math::Vector3*	rot;
	};

	static const std::vector<WeaponParamEntry>& GetWeaponParamEntries();

	// "[x, y, z]" 形式の行からベクトルを読み取る
	static bool ParseVec3(const std::string& line, Math::Vector3& out);

	std::unordered_map<std::string, AttackParam> m_attackParams;
};